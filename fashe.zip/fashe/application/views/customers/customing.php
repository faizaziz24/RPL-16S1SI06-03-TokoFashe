<!-- Title Page -->
<section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-image: url(<?php echo base_url(); ?>assets/images/heading-pages-06.jpeg);">
	<h2 class="l-text2 t-center">Ordering Transaction</h2>
</section>

<!-- Product Detail -->
<div class="container bgwhite p-t-35 p-b-80">
	<div class="flex-w flex-sb">
		<!-- Cart item -->
		<div class="container-table-cart pos-relative">
			<div class="wrap-table-shopping-cart bgwhite">
				<table class="table-shopping-cart">
					<tr class="table-head">
						<th class="column-1">No.</th>
						<th class="column-2">Penerima</th>
						<th class="column-2">Tanggal Pembelian</th>
						<th class="column-2">Total Pembayaran</th>
						<th class="column-3 p-l-25">Cetak</th>
					</tr>
					<tr class="table-row">
						<td class="column-1">
							asd
						</td>
						<td class="column-2">
							asd
						</td>
						<td class="column-2">
							asd
						</td>
						<td class="column-2">
							ads

						</td>
						<td class="column-3">
							<button class="flex-c-m sizefull bg1 bo-rad-23 hov1 s-text1 trans-0-4" name="btnCetak">
								Cetak
							</button>
						</td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</div>