    <footer class="app-footer">
      <div>
        <a href="<?php echo base_url(); ?>admin/dashboard">Fashion Leather</a>
        <span>&copy; 2018 fashe.</span>
      </div>
      <div class="ml-auto">
        <span>Powered by</span>
        <a href="<?php echo base_url(); ?>admin/dashboard">fashe.</a>
      </div>
    </footer>
    
    <!-- CoreUI and necessary plugins-->
    <script src="<?php echo base_url(); ?>assets/admin/vendors/jquery/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/vendors/popper.js/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/vendors/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/vendors/pace-progress/js/pace.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/vendors/perfect-scrollbar/js/perfect-scrollbar.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/vendors/@coreui/coreui/js/coreui.min.js"></script>
    <!-- Plugins and scripts required by this view-->
    <script src="<?php echo base_url(); ?>assets/admin/vendors/chart.js/js/Chart.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/vendors/@coreui/coreui-plugin-chartjs-custom-tooltips/js/custom-tooltips.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/main.js"></script>
    <script src="<?php echo base_url(); ?>assets/admin/js/ckeditor/ckeditor.js"></script>
      <script>
        CKEDITOR.replace('editor1');
      </script>
  </body>
</html>