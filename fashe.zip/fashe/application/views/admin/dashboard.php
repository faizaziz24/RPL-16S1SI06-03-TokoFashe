
<?php $this->load->view('admin/templates/header');?>
<?php $this->load->view('admin/templates/sidebar');?>
<?php $this->load->view('admin/templates/navigation');?>
<?php $this->load->view('admin/templates/footer');?>